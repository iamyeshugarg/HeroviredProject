from flask import Flask, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import redirect
from flask import session
app = Flask(__name__)
app.secret_key = "super secret key"

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'

db = SQLAlchemy(app)

admin_uname = str(1234)
admin_pwd = str(1234)
 
class studentDB(db.Model):
    sId = db.Column(db.Integer, primary_key=True)
    sName = db.Column(db.String, nullable=False, unique=True)
    pwd = db.Column(db.String, nullable=False)


class bookDB(db.Model):
    bId = db.Column(db.Integer, autoincrement=True, primary_key=True)
    bTitle = db.Column(db.String, nullable=False)
    aName = db.Column(db.String, nullable=False)
    bDesc = db.Column(db.String, nullable=False)
    count = db.Column(db.Integer, nullable=False)

class borrowDB(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    uId=db.Column(db.Integer, db.ForeignKey(studentDB.sId), nullable=False)
    bId=db.Column(db.Integer, db.ForeignKey(bookDB.bId), nullable=False)
    book = db.relationship("bookDB", backref="book", lazy=True)

@app.route('/')
def index():
    if 'user' in session:
        if session['user'] == int(admin_uname):
            return redirect('/admin-dashboard')
        else:
            id = session['user']
            return redirect(f'/student/{id}')    
    booklist = bookDB.query.all()
    return render_template('index.html',books=booklist)



@app.route('/admin-dashboard')
def adminDashboard():
    if 'user' in session:
        val = session['user']    
        if val == int(admin_uname):
            booklist = bookDB.query.all()
            return render_template('admin_dashboard.html',books=booklist)
        else:
            return redirect(f'/student/{val}')
    else:
        return redirect('/')

@app.route('/update-book/<int:id>',methods=['GET','POST'])
def updateBook(id):
    if 'user' in session:
        val = session['user']    
        if val == int(admin_uname):
            book = bookDB.query.filter_by(bId=id).scalar()    
            if request.method == 'POST':
                book.bTitle = request.form.get('title')
                book.aName = request.form.get('author')
                book.bDesc = request.form.get('description')
                book.count = int(request.form.get('count'))
                db.session.commit()
                return redirect('/admin-dashboard')
            else:
                return render_template('update_book.html',book=book)
        else:
            return redirect(f'/student/{val}')        
    else:
        return redirect('/') 
# add new book

@app.route('/add-book', methods=['POST'])
def addBook():
    if 'user' in session:
        val = session['user']    
        if val == int(admin_uname):
            bookName = request.form.get('bookName')
            authorName = request.form.get('authorName')
            bookDesc = request.form.get('bookDesc')
            count = int(request.form.get('count'))
            id = int(request.form.get('id'))
            newbook = bookDB(bId=id, bTitle=bookName, aName=authorName, bDesc=bookDesc, count=count)
            db.session.add(newbook)
            db.session.commit()
            return redirect('/admin-dashboard')
        else:
            return redirect(f'/student/{val}')
    else:   
        return redirect('/')


@app.route('/delete-book/<int:id>',methods=['POST','GET'])
def deleteBook(id):
    if 'user' in session :
        if session['user'] == int(admin_uname):
            if request.method == 'POST':
                book_to_delete = bookDB.query.get_or_404(id)
                try:
                    db.session.delete(book_to_delete)
                    db.session.commit()
                    return redirect('/admin-dashboard')
                except:
                    return 'There was a problem deleting that task.'
            else:
                return redirect('/admin-dashboard')        
        else:
            s_id = session['user']
            return redirect(f'/student/{s_id}')         
    else:
        return redirect('/sign-in')

@app.route('/sign-in', methods=['POST','GET'])
def signin():
    if 'user' in session:
        if session['user'] == int(admin_uname):
            return redirect('/admin-dashboard')
        else:
            id = session['user']
            return redirect(f'/student/{id}')    

    if request.method == 'POST':
        id = int(request.form.get('id'))
        password = request.form.get('password')
        if id == int(admin_uname) :
            if password == admin_pwd:
                session['user'] = id
                return redirect('/admin-dashboard')
            else:
                return render_template('handle_login.html',loginType = True, errMsg="Invalid Credentials...")
        user = studentDB.query.filter_by(sId=id).scalar()
        print(user)
        if user is not None:
            if user.pwd == password:
                session['user'] = id
                return redirect(f'/student/{id}')     
            else:
                return render_template('handle_login.html',loginType = True, errMsg="Invalid Credentials...")
        else:
            return render_template('handle_login.html',loginType = True, errMsg="Invalid Credentials...")
    return render_template('handle_login.html',loginType=True, errMsg=False)


@app.route('/register', methods=['POST','GET'])
def register():
    if 'user' in session:
        if session['user'] == int(admin_uname):
            return redirect('/admin-dashboard')
        else:
            id = session['user']
            return redirect(f'/student/{id}')    
            
    if request.method == 'POST':
        val = request.form.get('id')
        password = request.form.get('pwd')
        name = request.form.get('uname')
        id = int(val)

        user = studentDB.query.filter((studentDB.sId==id)|(studentDB.sName==name)).scalar()
        if id == admin_uname or user is not None: 
            return render_template('handle_login.html',loginType=False, errMsg="User Already Exists...")
        else:
            newUser = studentDB(sId=id, sName=name, pwd=password)
            db.session.add(newUser)
            db.session.commit()
            session['user'] = id
            return redirect(f'/student/{id}')  
    return render_template('handle_login.html',loginType=False, errMsg=False)




@app.route('/student/<int:id>/books')
def studentbooks(id):
    if 'user' in session:    
        val = session['user']
        if val == int(admin_uname):
            return redirect('/admin-dashboard')
        if val != id:
            return redirect(f'/student/{val}')    
        books = borrowDB.query.filter_by(uId=id).all()
        user = studentDB.query.filter_by(sId=id).scalar()
        booksName = []
        for item in books:
            booksName.append(item.book.bTitle)
        return render_template('borrowedBooks.html', books=booksName, user=user)
    else:
        return redirect('/')

@app.route('/borrow/<int:id>/<int:bid>', methods=['POST'])
def borrow(id,bid):
    if 'user' in session:
        val = session['user']
        if val == int(admin_uname):
            return redirect('/admin-dashboard')
        if val != id:
            return redirect(f'/student/{val}')
        book = bookDB.query.filter_by(bId=bid).scalar()
        if book.count == 0:
            return redirect(f'/student/{id}')
        bookBorrowed = borrowDB(uId=id,bId=bid)
        db.session.add(bookBorrowed)
        book.count -= 1
        db.session.commit()
        return redirect(f'/student/{id}')
    else:
        return redirect('/')    

@app.route('/logout')
def logout():
    if 'user' in session:
        session.pop('user')
        return redirect('/')
    return redirect('/')

@app.route("/student/<int:id>",methods=['POST'])
def searchBooks(id):
    if 'user' in session:
        books = bookDB.query.all()
        search = request.form["KeyWord"]
        s_id = session['user']
        user = studentDB.query.filter_by(sId=s_id).scalar()
        lbook= bookDB.query.filter(bookDB.bTitle.startswith(search)).all()
        return render_template('student.html',booksName=lbook, search=1, user=user)
    else:
        return redirect('/')    
    
@app.route('/student/<int:id>')
def studentDash(id):
    if 'user' in session:
        val = session['user']
        if val == int(admin_uname):
            return redirect('/admin-dashboard')
        if val != id:
            return redirect(f'/student/{val}')
        booklist = bookDB.query.all()
        user = studentDB.query.filter_by(sId=id).scalar()
        if user is None:
            return redirect(f'/student/{val}')
        return render_template('student.html',books=booklist, user=user)
    else:
        return redirect('/')

if __name__== "__main__":
    db.create_all()
    app.run(debug=True)